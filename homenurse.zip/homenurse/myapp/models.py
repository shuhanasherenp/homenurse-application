from django.db import models

# Create your models here.

class Login(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=20)
    type=models.CharField(max_length=50)
    
class Nurse(models.Model):
    name=models.CharField(max_length=80)
    dob=models.CharField(max_length=20)
    gender=models.CharField(max_length=30)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=20)
    district=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phoneno=models.CharField(max_length=20)
    qualification=models.CharField(max_length=300)
    photo=models.CharField(max_length=300)
    status=models.CharField(max_length=30,default="")
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
    # org_id=models.IntegerField()
    
class User(models.Model):  
    name=models.CharField(max_length=80)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=20)
    district=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)  
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
    
class Complaint(models.Model):
    date=models.DateField()
    complaint=models.CharField(max_length=200)
    reply=models.CharField(max_length=250)
    status=models.CharField(max_length=100)
    type=models.CharField(max_length=50)
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
        
class review_rating(models.Model):
    date=models.DateField(max_length=50)
    review=models.CharField(max_length=200)
    rating=models.CharField(max_length=100)
    NURSE=models.ForeignKey(Nurse,on_delete=models.CASCADE)
    USER=models.ForeignKey(User,on_delete=models.CASCADE)
    
    
    
    
class Request(models.Model):
    date=models.DateField()
    status=models.CharField(max_length=100)
    NURSE=models.ForeignKey(Nurse,on_delete=models.CASCADE)
    USER=models.ForeignKey(User,on_delete=models.CASCADE)
    
    
    
class Chat(models.Model):
    date=models.DateField()
    message=models.CharField(max_length=1000)
    FROMD=models.ForeignKey(Login,on_delete=models.CASCADE,related_name='log1')
    TOD=models.ForeignKey(Login,on_delete=models.CASCADE,related_name='log2')
    
     

    
    
    
class Trainer(models.Model):
    name=models.CharField(max_length=80)
    dob=models.CharField(max_length=20)
    gender=models.CharField(max_length=30)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=20)
    district=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)
    qualification=models.CharField(max_length=400)
    photo=models.CharField(max_length=400,default='')
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)   
    
class Tutor(models.Model):
    name=models.CharField(max_length=80)
    dob=models.CharField(max_length=20)
    gender=models.CharField(max_length=30)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=20)
    district=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)
    experience=models.CharField(max_length=300)
    photo=models.CharField(max_length=300)
    status=models.CharField(max_length=30,default="")
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
    TRAINER=models.ForeignKey(Trainer,on_delete=models.CASCADE)   
    
class Work_assign(models.Model):
    date=models.DateField()
    status=models.CharField(max_length=50)
    task=models.CharField(max_length=300)
    score=models.CharField(max_length=200)
    TUTOR=models.ForeignKey(Tutor,on_delete=models.CASCADE)
    NURSE=models.ForeignKey(Nurse,on_delete=models.CASCADE)
    
class Assign(models.Model):
    date=models.DateField()
    satus=models.CharField(max_length=50)
    TUTOR=models.ForeignKey(Tutor,on_delete=models.CASCADE)
    NURSE=models.ForeignKey(Nurse,on_delete=models.CASCADE)
    

    
    
class Organization(models.Model):
    name=models.CharField(max_length=200)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.CharField(max_length=20)
    district=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=20)
    proof=models.CharField(max_length=300)
    status=models.CharField(max_length=30,default="")
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
    
    
class Feedback(models.Model):
    date=models.DateField()
    Feedback=models.CharField(max_length=300)
    USER=models.ForeignKey(User,on_delete=models.CASCADE)
    
    
    
