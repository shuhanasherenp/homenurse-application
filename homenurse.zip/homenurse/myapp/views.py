
from datetime import datetime
from django.http import HttpResponse
from django.shortcuts import redirect, render

from myapp.models import *
from django.core.files.storage import FileSystemStorage

# Create your views here.
# a=Login()
# a.username='admin'
# a.password='admin'
# a.type='admin'
# a.save()

def login(request):
    return render(request,'login.html')
def login_post(request):
    uname=request.POST['uname']
    password=request.POST['password']
    print(uname)
    print(password)
    l=Login.objects.filter(username=uname,password=password)
    if l.exists():
        l2=Login.objects.get(username=uname,password=password)
        request.session['lid']=l2.id
        if l2.type=="admin":
            return HttpResponse('''<script>alert("Login success");window.location="/myapp/admin_home/"</script>''')

        if l2.type=="nurse":
            return HttpResponse('''<script>alert("Login success");window.location="/myapp/nurse_home/"</script>''')
        else:
             return HttpResponse('''<script>alert("invalid");window.location="/myapp/login/"</script>''')
    else:
         return HttpResponse('''<script>alert("invalid");window.location="/myapp/login/"</script>''')


def admin_view_registered_nurse_verify(request):
    res=Nurse.objects.filter(status='pending')
    print(res)
    return render(request,'admin/admin_view_registered_nurse_verify.html',{"data":res})
def admin_view_registered_nurse_verify_post(request):
    search=request.POST['search']
    res=Nurse.objects.filter(name__icontains=search)
    return render(request,'admin/admin_view_registered_nurse_verify.html',{"data":res})
def admin_add_trainer(request):
    return render(request,'admin/admin_add_trainer.html')
def admin_add_trainer_post(request):
    name=request.POST['name']
    date=request.POST['date']
    gen=request.POST['gen']
    qualification=request.POST['qualification']
    email=request.POST['email']
    place=request.POST['place']
    pincode=request.POST['pincode']
    post=request.POST['post']
    phoneno=request.POST['phoneno']
    district=request.POST['district']
    photo=request.FILES['photo']
    fs=FileSystemStorage()
    date=datetime.now().strftime("%Y%m%d-%H%M%S")+".jpg"
    fs.save(date,photo)
    path=fs.url(date)
    l=Login()
    l.username=email
    l.password=phoneno
    l.type='trainer'
    l.save()
    
    t=Trainer()
    t.name=name
    t.dob=date
    t.place=place
    t.gender=gen
    t.post=post
    t.pin=pincode
    t.district=district
    t.email=email
    t.phone=phoneno
    t.qualification=qualification
    t.photo=path
    t.LOGIN=l
    t.save()
    return HttpResponse('''<script>alert("add trainer successfully");window.location="/myapp/admin_view_trainer/"</script>''')

def admin_change_password(request):
    return render(request,'admin/admin_change_password.html')

def admin_change_password_post(request):
    current_password=request.POST['current_password']
    change_password=request.POST['change_password']
    confirm_password=request.POST['confirm_password']
    res=Login.objects.filter(id=request.session['lid'],password=current_password)
    if res.exists():
        if change_password==confirm_password:
            res=Login.objects.filter(id=request.session['lid'],password=current_password).update(password=confirm_password)
            return HttpResponse('''<script>alert("change password successfully");window.location="/myapp/login/"</script>''')
        else:
           return HttpResponse('''<script>alert("Invalid password,please try again....");window.location="/myapp/admin_change_password/"</script>''')
    else: 
        return HttpResponse('''<script>alert("Invalid user,please try again....");window.location="/myapp/admin_change_password/"</script>''')  
        
def admin_edit_trainer(request,id):
    t=Trainer.objects.get(LOGIN_id=id)
    return render(request,'admin/admin_edit_trainer.html',{"data":t})
def admin_edit_trainer_post(request):
    
    name=request.POST['name']
    date=request.POST['date']
    gen=request.POST['gen']
    qualification=request.POST['qualification']
    email=request.POST['email']
    place=request.POST['place']
    pincode=request.POST['pincode']
    post=request.POST['post']
    phoneno=request.POST['phoneno']
    district=request.POST['district']
    
    
    id=request.POST['id']
    l=Login.objects.get(id=id)
    l.username=email
    l.save()
    
    t=Trainer.objects.get(LOGIN_id=id)
    if 'photo' in request.FILES:
        photo=request.FILES['photo']
        fs=FileSystemStorage()
        date=datetime.now().strftime("%Y%m%d-%H%M%S")+".jpg"
        fs.save(date,photo)
        path=fs.url(date)
        t.photo=path
        t.save()
    t.name=name
    t.dob=date
    t.place=place
    t.gender=gen
    t.post=post
    t.pin=pincode
    t.district=district
    t.email=email
    t.phone=phoneno
    t.qualification=qualification
   
    t.save()
    return HttpResponse('''<script>alert("update trainer successfully");window.location="/myapp/admin_view_trainer/"</script>''')
def admin_home(request):
    return render(request,'admin/admin_home.html')
def admin_send_replay_tonurse(request,id):
    return render(request,'admin/admin_send_replay_tonurse.html',{"id":id})
def admin_send_replay_tonurse_post(request):
    id=request.POST['id']
    reply=request.POST['reply']
    Complaint.objects.filter(id=id).update(status="replyied",reply=reply)
    return HttpResponse('''<script>alert("replyied");window.location="/myapp/admin_view_complaint_from_nurse/"</script>''')
def admin_send_replay_touser(request):
    return render(request,'admin/admin_send_replay_touser.html')
def admin_send_replay_touser_post(request):
    reply=request.POST['reply']
    return HttpResponse("ok")
def admin_view_accept_organization(request):
    res=Organization.objects.filter(status="approved")
    return render(request,'admin/admin_view_accept_organization.html',{"data":res})
def admin_view_accept_organization_post(request):
    search=request.POST['search']
    res=Organization.objects.filter(name__icontains=search,status='approved')
    return render(request,'admin/admin_view_accept_organization.html',{"data":res})
def admin_view_approved_nurse(request):
    res=Nurse.objects.filter(status="approved")
    return render(request,'admin/admin_view_approved_nurse.html',{"data":res})
def admin_view_approved_nurse_post(request):
    search=request.POST['search']
    res=Nurse.objects.filter(name__icontains=search,status='approved')
    return render(request,'admin/admin_view_approved_nurse.html',{"data":res})
def admin_view_complaint_from_nurse(request):
    res=Complaint.objects.all()
    l=[]
    for i in res:
        name=""
        if i.type=='nurse':
            name=Nurse.objects.get(LOGIN_id=i.LOGIN_id)
        elif i.type=='user':
            name=User.objects.get(LOGIN_id=i.LOGIN_id)
        l.append({"id":i.id,"name":name.name,"place":name.place,"post":name.post,"pin":name.pin,"district":name.district,
                  "email":name.email,"date":i.date,"complaint":i.complaint,"reply":i.reply,"status":i.status,"type":i.type})
    return render(request,'admin/admin_view_complaint_from_nurse.html',{"data":l})
def admin_view_complaint_from_nurse_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    print(fromdate)
    res=Complaint.objects.filter(date__range=[fromdate,todate])
    l=[]
    for i in res:
        name=""
        if i.type=='nurse':
            name=Nurse.objects.get(LOGIN_id=i.LOGIN_id)
        elif i.type=='user':
            name=User.objects.get(LOGIN_id=i.LOGIN_id)
        l.append({"id":i.id,"name":name.name,"place":name.place,"post":name.post,"pin":name.pin,"district":name.district,"email":name.email,"date":i.date,"complaint":i.complaint,"reply":i.reply,"status":i.status,"type":i.type})
    return render(request,'admin/admin_view_complaint_from_user.html',{"data":l})

def admin_view_complaint_from_user(request):
    res=Complaint.objects.all()
    return render(request,'admin/admin_view_complaint_from_user.html')
def admin_view_complaint_from_user_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    return render(request,'admin/admin_view_complaint_from_user.html')
def admin_view_nurse_current_workingstatus(request,id):
    res=Work_assign.objects.filter(NURSE_id=id)
    return render(request,'admin/admin_view_nurse_current_workingstatus.html',{"data":res})
def admin_view_nurse_current_workingstatus_post(request):
    return render(request,'admin/admin_view_nurse_current_workingstatus.html')
def admin_view_nurse_rating_from_user(request):
    res=review_rating.objects.all()
    return render(request,'admin/admin_view_nurse_rating_from_user.html',{"data":res})

def admin_view_nurse_rating_from_user_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    res=review_rating.objects.filter(date__range=[fromdate,todate])
    return render(request,'admin/admin_view_nurse_rating_from_user.html',{"data":res})
def admin_view_organization(request):
    res=Organization.objects.filter(status="pending")
    return render(request,'admin/admin_view_organization.html',{"data":res})
def admin_view_organization_post(request):
    search=request.POST['search']
    res=Organization.objects.filter(name__icontains=search)
    return render(request,'admin/admin_view_organization.html',{"data":res})
def admin_view_rejected_nurse(request):
    res=Nurse.objects.filter(status="reject")
    return render(request,'admin/admin_view_rejected_nurse.html',{"data":res})
def admin_view_rejected_nurse_post(request):
    search=request.POST['search']
    res=Nurse.objects.filter(name__icontains=search,status='reject')
    return render(request,'admin/admin_view_rejected_nurse.html',{"data":res})
def admin_view_rejected_organization(request):
    res=Organization.objects.filter(status="reject")
    return render(request,'admin/admin_view_rejected_organization.html',{"data":res})
def admin_view_rejected_organization_post(request):
    search=request.POST['search']
    res=Organization.objects.filter(name__icontains=search,status='reject')
    return render(request,'admin/admin_view_rejected_organization.html',{"data":res})
def admin_view_trainer(request):
    res=Trainer.objects.all()
    return render(request,'admin/admin_view_trainer.html',{"data":res})
def admin_view_trainer_post(request):
    search=request.POST['search']
    return render(request,'admin/admin_view_trainer.html')

def admin_delete_trainer(request,id):
    res=Trainer.objects.filter(LOGIN=id).delete()
    res=Trainer.objects.filter(id=id).delete
    return redirect('/myapp/admin_view_trainer/')

def admin_view_tutor(request):  
    res=Tutor.objects.filter(status='pending')
    return render(request,'admin/admin_view_tutor.html',{"data":res})
def admin_view_tutor_post(request):
    search=request.POST['search']
    return render(request,'admin/admin_view_tutor.html')
def admin_view_user(request):
    res=User.objects.all()
    return render(request,'admin/admin_view_user.html',{"data":res})
def admin_view_user_post(request):
    search=request.POST['search']
    return render(request,'admin/admin_view_user.html')
def admin_approve_nurse(request,id):
    Login.objects.filter(id=id).update(type='nurse')
    Nurse.objects.filter(LOGIN_id=id).update(status='approved')
    return HttpResponse('''<script>alert("approved");window.location="/myapp/admin_view_registered_nurse_verify/"</script>''')
def admin_reject_nurse(request,id):
    Login.objects.filter(id=id).update(type='reject')
    Nurse.objects.filter(LOGIN_id=id).update(status='reject')
    return HttpResponse('''<script>alert("rejected");window.location="/myapp/admin_view_registered_nurse_verify/"</script>''')
def admin_approve_org(request,id):
    Login.objects.filter(id=id).update(type='organization')
    Organization.objects.filter(LOGIN_id=id).update(status='approved')
    return HttpResponse('''<script>alert("approved");window.location="/myapp/admin_view_organization/"</script>''')
def admin_reject_org(request,id):
    Login.objects.filter(id=id).update(type='reject')
    Organization.objects.filter(LOGIN_id=id).update(status='reject')
    return HttpResponse('''<script>alert("rejected");window.location="/myapp/admin_view_organization/"</script>''')






def nurse_change_password(request):
    return render(request,'nurse/nurse_change_password.html')
def nurse_change_password_post(request):
    current_password=request.POST['current_password']
    change_password=request.POST['change_password']
    confirm_password=request.POST['confirm_password']
    res=Login.objects.filter(id=request.session['lid'],password=current_password)
    if res.exists():
        if change_password==confirm_password:
            res=Login.objects.filter(id=request.session['lid'],password=current_password).update(password=confirm_password)
            return HttpResponse('''<script>alert("change password successfully");window.location="/myapp/login/"</script>''')
        else:
           return HttpResponse('''<script>alert("Invalid password,please try again....");window.location="/myapp/nurse_change_password/"</script>''')
    else: 
        return HttpResponse('''<script>alert("Invalid user,please try again....");window.location="/myapp/nurse_change_password/"</script>''')  
        
    
def nurse_home(request):
    return render(request,'nurse/nurse_home.html')
def nurse_edit_profile(request):
    a = Nurse.objects.get(LOGIN=request.session['lid'])
    return render(request,'nurse/nurse_edit_profile.html',{'data':a})
def nurse_edit_profile_post(request):
    name=request.POST['name']
    date=request.POST['date']
    gen=request.POST['gen']
    qualification=request.POST['qualification']
    email=request.POST['email']
    place=request.POST['place']
    pincode=request.POST['pincode']
    post=request.POST['post']
    phoneno=request.POST['phoneno']
    a=Nurse.objects.get(LOGIN=request.session['lid'])
    if 'photo' in request.FILES:
        photo=request.FILES['photo']

        fs = FileSystemStorage()
        date = datetime.now().strftime("%Y%m%d-%H%M%S") + ".jpg"
        fs.save(date, photo)
        path = fs.url(date)
        a.photo = path
        a.save()


    a.name = name
    a.dob = date
    a.gender = gen
    a.qualification = qualification
    a.email = email
    a.place = place
    a.pin = pincode
    a.post = post
    a.phoneno = phoneno
    a.status = 'pending'
    a.save()
    return HttpResponse('''<script>alert("successfully updated");window.location="/myapp/nurse_view_profile/"</script>''')





    return HttpResponse("ok")
def nurse_send_complaint_toadmin(request):
    return render(request,'nurse/nurse_send_complaint_toadmin.html')
def nurse_send_complaint_toadmin_post(request):
    complaint=request.POST['reply']
    c=Complaint()
    c.complaint=complaint
    c.reply='pending'
    c.status='pending'
    c.type='nurse'
    from datetime import datetime
    c.date=datetime.now().strftime('%Y-%m-%d')
    n=Nurse.objects.get(LOGIN=request.session['lid'])
    c.LOGIN_id=n.LOGIN.id
    c.save()
    return HttpResponse('''<script>alert("complaint send successfully, kindly waiting for reply.... ");window.location="/myapp/nurse_home/"</script>''')


def nurse_signup(request):
    return render(request,'nurse/nurse_signup.html')

def nurse_signup_post(request):
    name=request.POST['name']
    date=request.POST['date']
    gen=request.POST['gen']
    qualification=request.POST['qualification']
    email=request.POST['email']
    place=request.POST['place']
    pincode=request.POST['pincode']
    post=request.POST['post']
    phoneno=request.POST['phoneno']
    photo=request.FILES['photo']
    password=request.POST['password']
    confirm_password=request.POST['confirm_password']
    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y%m%d-%H%M%S") + ".jpg"
    fs.save(date, photo)
    path = fs.url(date)
    if password==confirm_password:
    
        res=Login()
        res.username=email
        res.password=confirm_password
        res.type='pending'
        res.save()
        a=Nurse()
        a.name=name
        a.dob=date
        a.gender=gen
        a.qualification=qualification
        a.email=email
        a.place=place
        a.pin=pincode
        a.post=post
        a.phoneno=phoneno
        a.photo=path
        a.status='pending'
        a.LOGIN=res
        a.save()





        return HttpResponse('''<script>alert("successfully registered");window.location="/myapp/login/"</script>''')
    else:
        return HttpResponse('''<script>alert(" incorrect password");window.location="/myapp/nurse_signup/"</script>''')

def nurse_view_profile(request):
    n=Nurse.objects.get(LOGIN=request.session['lid'])
    return render(request,'nurse/nurse_view_profile.html',{'data':n})
def nurse_view_profile_post(request):
    return render(request,'nurse/nurse_view_profile.html')
def nurse_view_replay_fromadmin(request):
    res=Complaint.objects.filter(LOGIN=request.session['lid'])
    return render(request,'nurse/nurse_view_replay_fromadmin.html',{'data':res})
def nurse_view_replay_fromadmin_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    res = Complaint.objects.filter(LOGIN=request.session['lid'],date__range=[fromdate,todate])
    return render(request, 'nurse/nurse_view_replay_fromadmin.html', {'data': res})


def nurse_view_review_from_user(request):
    res = review_rating.objects.filter(NURSE__LOGIN_id=request.session['lid'])
    return render(request,'nurse/nurse_view_review_from_user.html',{'data':res})
def nurse_view_review_from_user_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    res = Complaint.objects.filter(LOGIN=request.session['lid'], date__range=[fromdate, todate])
    return render(request, 'nurse/nurse_view_replay_fromadmin.html', {'data': res})
def nurse_view_user_request(request):
    res=Request.objects.filter(NURSE__LOGIN_id=request.session['lid'])
    return render(request,'nurse/nurse_view_user_request.html',{'data':res})
def nurse_view_user_request_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    res = Request.objects.filter(LOGIN=request.session['lid'], date__range=[fromdate, todate])
    return render(request,'nurse/nurse_view_user_request.html',{'data': res})





def org_add_nurse(request):
    return render(request,'organization/org_add_nurse.html')
def org_add_nurse_post(request):
    name = request.POST['name']
    date = request.POST['date']
    gen = request.POST['gen']
    qualification = request.POST['qualification']
    email = request.POST['email']
    place = request.POST['place']
    pincode = request.POST['pincode']
    post = request.POST['post']
    phoneno = request.POST['phone']
    photo = request.FILES['photo']

    fs = FileSystemStorage()
    date = datetime.now().strftime("%Y%m%d-%H%M%S") + ".jpg"
    fs.save(date, photo)
    path = fs.url(date)

    res = Login()
    res.username = email
    res.password = phoneno
    res.type = 'nurse'
    res.save()
    a = Nurse()
    a.name = name
    a.dob = date
    a.gender = gen
    a.qualification = qualification
    a.email = email
    a.place = place
    a.pin = pincode
    a.post = post
    a.phone = phoneno
    a.photo = path
    a.status = 'pending'
    a.LOGIN = res
    a.save()

    return HttpResponse('''<script>alert("successfully registered");window.location="/myapp/org_home/"</script>''')


def org_change_password(request):
    return render(request,'organization/org_change_password.html')
def org_change_password_post(request):
    current_password=request.POST['current_password']
    change_password=request.POST['change_password']
    confirm_password=request.POST['confirm_password']
    res = Login.objects.filter(id=request.session['lid'], password=current_password)
    if res.exists():
        if change_password == confirm_password:
            res = Login.objects.filter(id=request.session['lid'], password=current_password).update(
                password=confirm_password)
            return HttpResponse(
                '''<script>alert("change password successfully");window.location="/myapp/login/"</script>''')
        else:
            return HttpResponse(
                '''<script>alert("Invalid password,please try again....");window.location="/myapp/nurse_change_password/"</script>''')
    else:
        return HttpResponse(
            '''<script>alert("Invalid user,please try again....");window.location="/myapp/nurse_change_password/"</script>''')


def org_home(request):
    return render(request,'organization/org_home.html')
def org_signup(request):
    return render(request,'organization/org_signup.html')
def org_signup_post(request):
    name=request.POST['name']
    email=request.POST['email']
    place=request.POST['place']
    pincode=request.POST['pincode']
    post=request.POST['post']
    phoneno=request.POST['phoneno']
    proof=request.POST['proof']
    password=request.POST['password']
    confirm_password=request.POST['confirm_password']
    if password == confirm_password:

        lb = Login()
        lb.username = email
        lb.password = confirm_password
        lb.type = 'pending'
        lb.save()
        a = Nurse()
        a.name = name
        a.email = email
        a.place = place
        a.pin = pincode
        a.post = post
        a.proof=proof
        a.phoneno = phoneno
        a.status = 'pending'
        a.LOGIN = lb
        a.save()

        return HttpResponse('''<script>alert("successfully registered");window.location="/myapp/login/"</script>''')
    else:
        return HttpResponse('''<script>alert(" incorrect password");window.location="/myapp/nurse_signup/"</script>''')


def org_view_nurse(request):
    res=Nurse.objects.all()
    return render(request,'organization/org_view_nurse.html',{'data':res})
def org_view_nurse_post(request):
    return render(request,'organization/org_view_nurse.html')
def org_edit_nurse(request,id):
    res=Nurse.objects.get(id=id)

    return render(request,'organization/org_edit_nurse.html',{'data':res})
def org_edit_nurse_post(request):
    did=request.POST['id1']
    name = request.POST['name']
    date = request.POST['date']
    gen = request.POST['gen']
    qualification = request.POST['qualification']
    email = request.POST['email']
    place = request.POST['place']
    pincode = request.POST['pincode']
    post = request.POST['post']
    phoneno = request.POST['phone']
    if 'photo' in request.FILES:
        photo = request.FILES['photo']
        if photo !='':
            fs = FileSystemStorage()
            date = datetime.now().strftime("%Y%m%d-%H%M%S") + ".jpg"
            fs.save(date, photo)
            path = fs.url(date)
            a = Nurse.objects.get(id=did)
            a.photo = path
            a.save()
    a = Nurse.objects.get(id=did)
    a.name = name
    a.dob = date
    a.gender = gen
    a.qualification = qualification
    a.email = email
    a.place = place
    a.pin = pincode
    a.post = post
    a.phone = phoneno

    a.save()
    return HttpResponse('''<script>alert("successfully updated");window.location="/myapp/org_view_nurse/"</script>''')

def org_delete_nurse(request,id):
    res=Nurse.objects.get(id=id).delete()
    return HttpResponse('''<script>alert("successfully deleted");window.location="/myapp/org_view_nurse/"</script>''')
def org_view_user_request(request):
    return render(request,'organization/org_view_user_request.html')
def org_view_user_request_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    return render(request,'organization/org_view_user_request.html')








def tainer_assign_nurse_totutor(request):
    return render(request,'trainer/tainer_assign_nurse_totutor.html')
def tainer_assign_nurse_totutor_post(request):
    return HttpResponse("ok")
def trainer_change_password(request):
    return render(request,'trainer/trainer_change_password.html')
def trainer_change_password_post(request):
    current_password=request.POST['current_password']
    change_password=request.POST['change_password']
    confirm_password=request.POST['confirm_password']
    return HttpResponse("ok")
def trainer_home(request):
    return render(request,'trainer/trainer_home.html')
def trainer_manage_tutor(request):
    return render(request,'trainer/trainer_manage_tutor.html')
def trainer_manage_tutor_post(request):
    name=request.POST['name']
    search=request.POST['search']
    return HttpResponse("ok")
def trainer_view_profile(request):
    return render(request,'trainer_view_profile.html')
def trainer_view_profile_post(request):
    return render(request,'trainer_view_profile.html')
def trainer_view_work_report(request):
    return render(request,'trainer/trainer_view_work_report.html')
def trainer_view_work_report_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    return render(request,'trainer/trainer_view_work_report.html')






def tutor_view_assigned_nurse(request):
    return render(request,'tutor/tutor view assigned_nurse.html')
def tutor_view_assigned_nurse_post(request):
    return render(request,'tutor/tutor view assigned_nurse.html')
def tutor_change_password(request):
    return render(request,'tutor/tutor_change_password.html')
def tutor_change_password_post(request):
    current_password=request.POST['current_password']
    change_password=request.POST['change_password']
    confirm_password=request.POST['confirm_password']
    return HttpResponse("ok")
def tutor_home(request):
    return render(request,'tutor/tutor_home.html')
def tutor_signup(request):
    return render(request,'tutor/tutor_signup.html')
def tutor_signup_post(request):
    name=request.POST['name']
    date=request.POST['date']
    gen=request.POST['gen']
    experience=request.POST['experience']
    email=request.POST['email']
    place=request.POST['place']
    pincode=request.POST['pincode']
    post=request.POST['post']
    phoneno=request.POST['phoneno']
    photo=request.POST['photo']
    password=request.POST['password']
    confirm_password=request.POST['confirm_password']
    return HttpResponse("ok")
def tutor_assign_work_to_nurse(request):
    return render(request,'tutor/tutor_assign_work_to_nurse.html')
def tutor_assign_work_to_nurse_post(request):
    select=request.POST['select']
    return HttpResponse("ok")
def tutor_view_work_status(request):
    return render(request,'tutor/tutor_view_work_status.html')
def tutor_view_work_status_post(request):
    fromdate=request.POST['from']
    todate=request.POST['to']
    return render(request,'tutor/tutor_view_work_status.html')

